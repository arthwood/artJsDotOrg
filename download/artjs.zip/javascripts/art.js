var ArtJs = {
  artJsNavigators: {
    'Microsoft Internet Explorer': 'ie',
    'Netscape': 'ff',
    'Opera': 'ff'
  },
  artJsPath: window.ART_JS_PATH || 'javascripts/'
};

ArtJs.artJsPackage = ArtJs.artJsNavigators[navigator.appName];

document.write('<script type="text/javascript" src="' + ArtJs.artJsPath + 'art.' + ArtJs.artJsPackage + '.js' + '"></script>');

var ArtJs = {
  navigators: {
    'Microsoft Internet Explorer': 'ie',
    'Netscape': 'ff',
    'Opera': 'ff'
  },
  setup: function() {
    var appName = navigator.appName;
    var appVersion = navigator.appVersion;
    var package = this.navigators[appName];
    var path = window.ART_JS_PATH || 'javascripts/';
    var version = /MSIE\s(6|7)\.0/.test(appVersion);
    
    this.success = !(package == 'ie' && version);
    
    if (this.success) {
      document.write('<script type="text/javascript" src="' + path + 'art.' + package + '.js' + '"></script>');
    }
  }
};

ArtJs.setup();

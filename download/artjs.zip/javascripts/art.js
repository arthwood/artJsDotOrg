var ArtJs = {
  navigator: {
    'Microsoft Internet Explorer': 'ie',
    'Netscape': 'ff',
    'Opera': 'ff'
  },
  path: window.ART_JS_PATH || 'javascripts/'
};

ArtJs.package = ArtJs.navigator[navigator.appName];

document.write('<script type="text/javascript" src="' + ArtJs.path + 'art.' + ArtJs.package + '.js' + '"></script>');
